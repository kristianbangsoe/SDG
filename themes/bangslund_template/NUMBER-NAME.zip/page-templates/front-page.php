<?php /* Template Name: Front page */ ?>

<?php  get_header();  ?>

<?php
include __DIR__ . '/../module-templates/builder.php';
?>

<?php
get_footer();