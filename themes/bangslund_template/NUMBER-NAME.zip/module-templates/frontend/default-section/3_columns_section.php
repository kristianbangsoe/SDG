<?php
/**
 * Created by Daniela P.
 * User: html24
 * Date: 05/10/18
 * Time: 17:28
 */
?>

<?php
//get section block fields

?>

<!--start 3 columns section markup -->
<section class="three_column_section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-4"><h1>Column 1</h1></div>
            <div class="col-12 col-md-4"><h1>Column 2</h1></div>
            <div class="col-12 col-md-4"><h1>Column 3</h1></div>
        </div></div>
</section>
<!--end 3 columnssection markup -->