<?php
/**
 * Created by Daniela P.
 * User: html24
 * Date: 30/10/18
 * Time: 09:45
 */

?>

<?php
//get section block fields

?>

<!--start full width section markup -->
<section class="full_width_section">
    <div class="container-fluid">
        <h1>Full width section
        </h1>
    </div>
</section>
<!--end full width section markup -->