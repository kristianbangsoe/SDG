<?php 
header("Location: /find-projects");